# FBNeo Pocket

A compact Android frontend for the FBNeo libretro core. It does not include game ROMs; import files you are legally entitled to use.

## What's implemented

- Dark, arcade-inspired Android UI.
- Android Storage Access Framework file pickers for local ROM archives and Lua scripts.
- Bundles the FBNeo Android core at CI build time for `arm64-v8a` and `armeabi-v7a`.
- Launch path uses LibretroDroid's `GLRetroView` to load the selected ROM with the bundled FBNeo core.
- Lua file selection and source preview.
- GitHub Actions builds a debug APK, uploads it as a downloadable artifact, and creates a GitHub Release when a `v*` tag is pushed.

## Important current limitations

- **Lua scripts are selected and previewed, but not executed against FBNeo yet.** FBNeo-specific Lua scripts depend on emulator callbacks and APIs (memory, input, frame hooks, GUI drawing). Those need a dedicated bridge compatible with the script you provide. The libretro core alone does not expose FBNeo's standalone Lua API to this app.
- Virtual touch arcade controls and a full in-app settings screen are not finished. Physical controller support depends on the LibretroDroid integration and device input mapping.
- The build downloads FBNeo core binaries from the Libretro buildbot during CI; builds therefore require network access and upstream core availability.
- The GitHub workflow builds a **debug APK**. It is suitable for testing, not a signed production release.

## Build APK on GitHub

1. Upload the contents of this project to your repository root (including `.github/workflows/android.yml`).
2. Open **Actions** and run **Build FBNeo Pocket APK**, or push a commit to `main`/`master`.
3. Open the completed run. Download `fbneo-pocket-debug-apk` under **Artifacts**.
4. For a GitHub Release, create and push a version tag such as `v0.2.0`; the workflow attaches `app-debug.apk` to that release.

## Local build

Install JDK 17, Android SDK platform 35, and Android build tools. Place the FBNeo core libraries at:

- `app/src/main/jniLibs/arm64-v8a/libfbneo_libretro_android.so`
- `app/src/main/jniLibs/armeabi-v7a/libfbneo_libretro_android.so`

Then run `gradle assembleDebug` from the project root. CI fetches these binaries automatically.

## Core and frontend references

- FBNeo: https://github.com/libretro/FBNeo
- FBNeo core documentation: https://docs.libretro.com/library/fbneo/
- LibretroDroid Android frontend bridge: https://github.com/Swordfish90/LibretroDroid

The upstream FBNeo project is licensed under its own terms, and LibretroDroid is GPL-3.0. Review the relevant licenses before redistributing modified builds.
