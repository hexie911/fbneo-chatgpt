package com.hexie.fbneopocket

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Modifier

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 22)
    private val panel = Color.rgb(27, 28, 38)
    private val panel2 = Color.rgb(36, 37, 49)
    private val accent = Color.rgb(183, 243, 107)
    private val text = Color.rgb(247, 247, 250)
    private val muted = Color.rgb(160, 163, 181)
    private var romUri: Uri? = null
    private var luaUri: Uri? = null
    private lateinit var romLabel: TextView
    private lateinit var luaLabel: TextView
    private lateinit var libraryLabel: TextView
    private lateinit var launchButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        renderHome()
    }

    private fun renderHome() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(14))
        }
        val scroll = ScrollView(this).apply { clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(20)) }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "FB"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(bg); setBackgroundColor(accent); setPadding(dp(11), dp(8), dp(11), dp(8))
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(46), dp(42)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        brand.addView(label("FBNEO POCKET", 14, text, true))
        brand.addView(label("ARCADE FRONTEND", 10, muted, true))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(label("BETA 0.2", 10, accent, true))
        content.addView(top)
        content.addView(space(26))
        content.addView(label("YOUR ARCADE.\nYOUR RULES.", 31, text, true))
        content.addView(space(9))
        content.addView(label("A focused home for your own FBNeo game files.", 14, muted, false))
        content.addView(space(23))

        val hero = card()
        hero.addView(label("CURRENT SESSION", 10, accent, true))
        hero.addView(space(14))
        hero.addView(label("${if (romUri == null) "Ready when you are." else "ROM selected."}", 22, text, true))
        hero.addView(space(7))
        hero.addView(label("${if (romUri == null) "Choose a ROM set to start a session." else "Your selected file is ready to launch."}", 13, muted, false))
        hero.addView(space(15))
        romLabel = label(romUri?.let { displayName(it) } ?: "NO GAME SELECTED", 12, text, true)
        hero.addView(romLabel)
        hero.addView(space(15))
        launchButton = button(if (romUri == null) "＋   Choose ROM file" else "▶   Launch game", true) {
            if (romUri == null) pickRom() else launchGame()
        }
        hero.addView(launchButton, LinearLayout.LayoutParams(-1, dp(48)))
        if (romUri != null) {
            hero.addView(space(8))
            hero.addView(button("Choose a different ROM", false) { pickRom() }, LinearLayout.LayoutParams(-1, dp(44)))
        }
        content.addView(hero)
        content.addView(space(14))

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val library = card(); library.addView(label("LIBRARY", 10, muted, true)); library.addView(space(8)); library.addView(label("Local files", 17, text, true)); library.addView(space(5)); libraryLabel = label("${if (romUri == null) "No ROM added yet" else "1 ROM selected"}", 12, muted, false); library.addView(libraryLabel); library.addView(space(13)); library.addView(button("Browse ROMs", false) { pickRom() }, LinearLayout.LayoutParams(-1, dp(42)))
        val scripts = card(); scripts.addView(label("SCRIPTS", 10, muted, true)); scripts.addView(space(8)); scripts.addView(label("Lua tools", 17, text, true)); scripts.addView(space(5)); luaLabel = label(luaUri?.let { displayName(it) } ?: "No script selected", 12, muted, false); scripts.addView(luaLabel); scripts.addView(space(13)); scripts.addView(button("Choose .lua", false) { pickLua() }, LinearLayout.LayoutParams(-1, dp(42)))
        quick.addView(library, LinearLayout.LayoutParams(0, -2, 1f)); quick.addView(spaceHorizontal(10)); quick.addView(scripts, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(quick)
        content.addView(space(14))

        val tools = card()
        tools.addView(label("BUILT FOR YOUR SETUP", 10, accent, true))
        tools.addView(space(12))
        tools.addView(feature("01", "Your ROMs stay yours", "Pick supported local ZIP/7z sets from device storage."))
        tools.addView(space(13))
        tools.addView(feature("02", "Gamepad-ready foundation", "Designed for touch controls and external controllers."))
        tools.addView(space(13))
        tools.addView(feature("03", "Lua script library", "Import and inspect scripts; FBNeo-specific script execution still needs its compatible API bridge."))
        content.addView(tools)
        content.addView(space(20))
        val footer = label("OFFLINE-FIRST  •  NO ROMS INCLUDED", 10, muted, true).apply { gravity = Gravity.CENTER }
        content.addView(footer)
        setContentView(outer)
    }

    private fun pickRom() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-7z-compressed", "application/octet-stream"))
        }
        startActivityForResult(intent, 101)
    }

    private fun pickLua() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/*" }
        startActivityForResult(intent, 102)
    }

    @Deprecated("Legacy callback kept for Android API 23 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        when (requestCode) {
            101 -> { romUri = uri; renderHome() }
            102 -> { luaUri = uri; showLuaPreview(uri); renderHome() }
        }
    }

    private fun launchGame() {
        val uri = romUri ?: return
        val name = displayName(uri)
        try {
            val localRom = copyToCache(uri, safeName(name))
            val coreFile = File(applicationInfo.nativeLibraryDir, "libfbneo_libretro_android.so")
            if (!coreFile.exists()) {
                AlertDialog.Builder(this).setTitle("Emulator core missing")
                    .setMessage("The Android build needs the FBNeo core bundled by GitHub Actions. Rebuild using the current workflow and check the APK artifact.")
                    .setPositiveButton("OK", null).show()
                return
            }
            val viewClass = Class.forName("com.swordfish.libretrodroid.GLRetroView")
            val constructor = viewClass.constructors.firstOrNull { it.parameterTypes.size == 6 }
                ?: throw IllegalStateException("Compatible LibretroDroid view constructor not found")
            val shader = try { Class.forName("com.swordfish.libretrodroid.LibretroDroid").getField("SHADER_NONE").getInt(null) } catch (_: Exception) { 0 }
            val view = constructor.newInstance(this, coreFile.absolutePath, localRom.absolutePath, filesDir.absolutePath, filesDir.absolutePath, shader) as View
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
            setContentView(view)
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Could not launch game")
                .setMessage("${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}\n\nCheck that the ROM set matches this FBNeo core and that the APK includes the core for your device architecture.")
                .setPositiveButton("OK") { _, _ -> renderHome() }.show()
        }
    }

    private fun showLuaPreview(uri: Uri) {
        try {
            val source = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            val preview = TextView(this).apply { text = source.take(12000); textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(text); setPadding(dp(16), dp(12), dp(16), dp(12)) }
            val scroll = ScrollView(this).apply { addView(preview) }
            AlertDialog.Builder(this).setTitle("Lua script preview").setView(scroll).setPositiveButton("Close", null).show()
        } catch (e: Exception) {
            toast("Could not read script: ${e.message}")
        }
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val dir = File(cacheDir, "roms").apply { mkdirs() }
        val out = File(dir, name)
        contentResolver.openInputStream(uri).use { input -> FileOutputStream(out).use { output -> input?.copyTo(output) ?: error("Cannot read selected file") } }
        return out
    }

    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) ?: uri.lastPathSegment ?: "Selected file" else uri.lastPathSegment ?: "Selected file"
        } ?: (uri.lastPathSegment ?: "Selected file")
    } catch (_: Exception) { uri.lastPathSegment ?: "Selected file" }

    private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120).ifBlank { "game.zip" }
    private fun feature(number: String, title: String, description: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        row.addView(label(number, 11, accent, true), LinearLayout.LayoutParams(dp(34), -2))
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(label(title, 14, text, true)); column.addView(space(4)); column.addView(label(description, 12, muted, false))
        row.addView(column, LinearLayout.LayoutParams(0, -2, 1f)); return row
    }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(panel, 18) }
    private fun label(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setLineSpacing(dp(2).toFloat(), 1f) }
    private fun button(value: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = value; textSize = 13f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (primary) bg else text)
        background = rounded(if (primary) accent else panel2, 12); setPadding(dp(12), 0, dp(12), 0); setOnClickListener { action() }
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun spaceHorizontal(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
