package com.example.fbneo

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 24)
    private val panel = Color.rgb(29, 29, 43)
    private val accent = Color.rgb(167, 139, 250)
    private val muted = Color.rgb(165, 165, 185)
    private var romUri: Uri? = null
    private var luaUri: Uri? = null
    private lateinit var romStatus: TextView
    private lateinit var luaStatus: TextView
    private lateinit var notice: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(20)); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(24)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("FB NEO / POCKET", 12, accent, true))
        content.addView(space(8))
        content.addView(label("Arcade,\nyour way.", 34, Color.WHITE, true))
        content.addView(space(8))
        content.addView(label("A clean Android frontend prototype for your own game files and Lua scripts.", 15, muted, false))
        content.addView(space(24))

        val gameCard = card()
        gameCard.addView(label("NOW PLAYING", 11, muted, true))
        gameCard.addView(space(12))
        gameCard.addView(label("No game loaded", 21, Color.WHITE, true))
        gameCard.addView(space(6))
        gameCard.addView(label("Choose a local ROM set to add it to this session.", 13, muted, false))
        gameCard.addView(space(16))
        romStatus = label("No ROM selected", 13, Color.WHITE, false)
        gameCard.addView(romStatus)
        gameCard.addView(space(12))
        gameCard.addView(actionButton("Choose ROM file", true) { pickRom() })
        content.addView(gameCard)
        content.addView(space(16))

        val luaCard = card()
        luaCard.addView(label("LUA SCRIPTS", 11, muted, true))
        luaCard.addView(space(8))
        luaCard.addView(label("Bring your own scripts", 19, Color.WHITE, true))
        luaCard.addView(space(6))
        luaCard.addView(label("Select a .lua file. Running it requires a compatible FBNeo scripting bridge, which is not connected in this prototype yet.", 13, muted, false))
        luaCard.addView(space(14))
        luaStatus = label("No Lua script selected", 13, Color.WHITE, false)
        luaCard.addView(luaStatus)
        luaCard.addView(space(12))
        luaCard.addView(actionButton("Choose Lua script", false) { pickLua() })
        content.addView(luaCard)
        content.addView(space(16))

        val infoCard = card()
        infoCard.addView(label("BUILD STATUS", 11, accent, true))
        infoCard.addView(space(8))
        infoCard.addView(label("Frontend prototype", 18, Color.WHITE, true))
        infoCard.addView(space(6))
        infoCard.addView(label("This build has file selection and the UI only. The FBNeo emulation core, game rendering, controls, and Lua execution still need to be integrated before it can play games.", 13, muted, false))
        content.addView(infoCard)
        content.addView(space(18))
        notice = label("Files stay on your device; nothing is uploaded by this app.", 12, muted, false)
        notice.gravity = Gravity.CENTER
        content.addView(notice)
        setContentView(root)
    }

    private fun pickRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-7z-compressed", "application/octet-stream")) }
        startActivityForResult(i, 100)
    }
    private fun pickLua() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/*" }
        startActivityForResult(i, 101)
    }
    @Deprecated("Deprecated by Android API but retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: uri.toString()
        when (requestCode) {
            100 -> { romUri = uri; romStatus.text = "Selected: $name"; notice.text = "ROM selected. Emulation is not wired up yet." }
            101 -> { luaUri = uri; luaStatus.text = "Selected: $name"; notice.text = "Lua file selected. Script execution is not wired up yet." }
        }
    }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(panel, dp(20)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setLineSpacing(dp(2).toFloat(), 1f) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun actionButton(text: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(if (primary) Color.rgb(20, 18, 30) else Color.WHITE)
        background = rounded(if (primary) accent else Color.rgb(48, 47, 67), dp(14)); setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
