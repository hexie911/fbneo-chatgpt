# FBNeo Pocket — Android frontend prototype

A small Android UI prototype for an eventual standalone FBNeo-based emulator. It currently builds an APK with a polished dark UI and Android Storage Access Framework pickers for local ROM archives and Lua scripts.

## Current status — prototype, not an emulator yet

Implemented:
- Android app shell and dark UI
- Local document picker for ROM archives (ZIP/7z and generic file types)
- Local document picker for Lua scripts
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

Not implemented yet:
- FBNeo/libretro core compiled for Android and bundled into the APK
- Native libretro frontend bridge (load game, frame/audio callbacks, input, lifecycle)
- Actual ROM loading or game rendering
- Touch arcade controls and controller mapping
- FBNeo-compatible Lua engine/API bridge and script execution

The app deliberately labels these missing parts rather than pretending selected files are being emulated. Lua support must be matched to the API expected by the user's script; send the script before deciding which callbacks/features are needed.

## Build on GitHub

1. Create a new GitHub repository and upload all files in this project.
2. Open **Actions** and enable workflows if prompted.
3. Run **Build FBNeo Pocket APK**, or push to `main`/`master`.
4. Download `fbneo-pocket-debug-apk` from the completed workflow run's **Artifacts** section.

The workflow builds a debug APK only. It does not create a release or sign a production APK.

## Core reference

FBNeo's libretro port is at https://github.com/libretro/FBNeo. Its documented build command is `make -C src/burner/libretro`; Android cross-compilation and frontend integration still need to be added to this project. See https://docs.libretro.com/library/fbneo/ for supported ROM formats and requirements.

Only use ROM files you are legally entitled to use. The app does not download ROMs.
